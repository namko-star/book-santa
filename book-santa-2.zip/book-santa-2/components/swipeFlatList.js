import React, {Component} from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, TouchableHighlight, Dimensions, Animated } from 'react-native';
import { Icon, ListItem } from 'react-native-elements';
import { SwipeListView } from 'react-native-swipe-list-view';

import db from '../config';
import firebase from 'firebase';

export default class SwipeFlatList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      allNotifications: this.props.allNotifications
    }
  }

  onSwipeValueChange = swipeData => {
    var allNotifications = this.state.allNotifications
    const { key, value } = swipeData
    if(value < -Dimensions.get("window").width) {
      const newData = [...allNotifications]
      this.updateMarkAsRead(allNotifications[key])
      newData.splice(key, 1)
      this.setState({
        allNotifications: newData
      })
    }
  }

  renderItem = data => (
    <Animated.View>
      <ListItem
        leftElement = {<Icon name = 'book' type = 'font-awesome'/>}
        title = {data.item.book_name}
        titleStyle = {{color: 'black'}}
        subtitle = {data.item.message}
        bottomDivider
      />
    </Animated.View>
  )

  closeRow = (item, key) => {
    if(item[key]) {
      item[key].closeRow();
    }
  }

  deleteRow = (item, key) => {
    var allNotifications = this.state.allNotifications;
    this.closeRow(item, key)
    const newData = [...allNotifications]
    const previewIndex = allNotifications.findIndex(item => item.key === key)
    this.updateMarkAsRead(allNotifications[previewIndex])
    newData.splice(previewIndex, 1)
    this.setState({
      allNotifications: newData
    })
  }

  updateMarkAsRead = (notification) => {
    db.collection('all_notifications').doc(notification.doc_id).update({
      "notification_status": "read"
    })
  }

  renderHiddenItem = () => (
    <View style = {{flexDirection: 'row', flex: 1, backgroundColor: 'pink'}}>
      <Text>Mark as Read</Text>
    </View>
  )

  render() {
    return(
      <View style = {{flex: 1}}>
        <SwipeListView
          disableRightSwipe
          data = {this.state.allNotifications}
          renderItem = {this.renderItem}
          renderHiddenItem = {this.renderHiddenItem}
          leftOpenValue = {75}
          rightOpenValue = {-Dimensions.get("window").width}
          previewRowKey = {"0"}
          previewOpenValue = {-40}
          previewOpenDelay = {3000}
          onSwipeValueChange = {this.onSwipeValueChange}
          keyExtractor = {(item, index) => index.toString()}
        />
      </View>
    );
  }

}