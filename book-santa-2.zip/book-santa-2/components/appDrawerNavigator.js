import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Modal, ScrollView, KeyboardAvoidingView } from 'react-native';
import { AppTabNavigator } from './appTabNavigator';
import CustomSideBarMenu from './customSideBarMenu';
import { createDrawerNavigator } from 'react-navigation-drawer';
import SettingsScreen from '../screens/settingsScreen';
import MyDonationsScreen from '../screens/myDonations';
import NotificationsScreen from '../screens/notificationsScreen';

export const AppDrawerNavigator = createDrawerNavigator({
  Home : {
    screen : AppTabNavigator
  },
  
  Settings : {
    screen: SettingsScreen
  },

  Donations: {
    screen: MyDonationsScreen
  },

  Notifications: {
    screen: NotificationsScreen
  }
},

  {
    contentComponent:CustomSideBarMenu
  },
  {
    initialRouteName : 'Home'
  })
