import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Modal, ScrollView, KeyboardAvoidingView } from 'react-native';
import { Header, Icon, Badge, withBadge } from 'react-native-elements';

import firebase from 'firebase';
import db from '../config';

export default class MyHeader extends Component {
  constructor(props) {
    super();
    this.state = {
      value: ''
    }
  }

  getNumberOfUnreadNotifications() {
    db.collection('all_notifications').where('notification_status', '==', 'unread')
    .onSnapshot((snapshot) => {
      var unreadNotifications = snapshot.docs.map((doc) => doc.data())
      this.setState({
        value: unreadNotifications.length
      })
    })
  }

  componentDidMount() {
    this.getNumberOfUnreadNotifications();
  }

  BellIconWithBadge = () => {
    return(
      <View>
        <Icon name = 'bell' type = 'font-awesome' color = 'white'
        onPress = {() => {
          this.props.navigation.navigate('Notifications')
        }}/>
        <Badge value = {this.state.value} containerStyle = {{top: -4, position: "absolute", right: -4}}/>
      </View>
    );
  }

  render() {
    return(
      <Header
        leftComponent = {<Icon name = 'bars' type = 'font-awesome' color = 'white' 
        onPress = {() => {
          this.props.navigation.toggleDrawer();
        }}/>}
        centerComponent = {{text: this.props.title, style: {color: 'white', fontSize: 20, fontWeight: 'bold'}}}
        rightComponent = {<this.BellIconWithBadge {...this.props}/>}
        backgroundColor = 'pink'
      />
    );
  }
}
