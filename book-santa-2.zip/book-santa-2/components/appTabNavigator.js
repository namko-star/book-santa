import React, { Component } from 'react';
import { Image } from 'react-native';
import { createBottomTabNavigator } from 'react-navigation-tabs';

import { AppStackNavigator } from './appStackNavigator';
import BookDonateScreen from '../screens/bookDonateScreen';
import BookRequestScreen from '../screens/bookRequestScreen';

export const AppTabNavigator = createBottomTabNavigator({
  DonateBooks: {
    screen: AppStackNavigator,
    navigationOptions: {
      tabBarIcon: <Image source = {require("../assets/openBook.png")} style = {{width: 20, height: 20}}/>,
      tabBarLabel: "Donate Book"
    }
  },

  RequestBooks: {
    screen: BookRequestScreen,
    navigationOptions: {
      tabBarIcon: <Image source = {require("../assets/requestbook.png")} style = {{width: 20, height: 20}}/>,
      tabBarLabel: "Request Book"
    }
  }
});