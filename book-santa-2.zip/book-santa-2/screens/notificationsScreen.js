import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Modal, ScrollView, KeyboardAvoidingView, Image, FlatList } from 'react-native';
import { Icon, ListItem } from 'react-native-elements';
import MyHeader from "../components/myHeader"
import SwipeFlatList from '../components/swipeFlatList';
import db from '../config';
import firebase from 'firebase';

export default class NotificationsScreen extends Component {
  constructor() {
    super();
    this.state = {
      userID: firebase.auth().currentUser.email,
      allNotifications: []
    }
    this.notificationRef = null;
  }

  getNotifications = () => {
    this.requestRef = db.collection("all_notifications").where("notification_status", '==', "unread")
    .where("targeted_user_id", '==', this.state.userID)
    .onSnapshot((snapshot) => {
      var all_notifications = []
      snapshot.docs.map((doc) => {
        var notification = doc.data() 
        notification["doc_id"] = doc.id 
        all_notifications.push(notification)
      })
      this.setState({
        allNotifications: all_notifications
      })
    })
  }

  componentDidMount() {
    this.getNotifications();
  }

  componentWillUnmount() {
    this.notificationRef
  }

  keyExtractor = (item, index) => index.toString();

  renderItem = ({ item, index }) => {
    return (
      <ListItem
        key={index}
        title={item.book_name}
        subtitle={item.reason_to_request}
        titleStyle={{ color: "black", fontWeight: "bold" }}
        leftElement = {
          <Icon name = "Book" type = "font-awesome" color = "blue"/>
        }
        bottomDivider
      />
    );
  };

  render() {
    return(
      <View style={styles.container}>
        <View style={{flex:0.1}}>
          <MyHeader title={"Notifications"} navigation={this.props.navigation}/>
        </View>
        <View style={{flex:0.9}}>
          {
            this.state.allNotifications.length === 0
            ?(
              <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
                <Text style={{fontSize:25}}>You have no notifications</Text>
              </View>
            )
            :(
              <SwipeFlatList allNotifications = {this.state.allNotifications}/>
            )
          }
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
})