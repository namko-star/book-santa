import React, { Component } from 'react';
import { Text, View, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import MyHeader from '../components/myHeader';

import firebase from 'firebase';
import db from '../config'

export default class SettingsScreen extends Component {
  constructor(){
    super();
    this.state = {
      emailID: "",
      password: "",
      firstName: "",
      lastName: "",
      address: "",
      contact: "",
      docID: ""
    }
  }
  
  componentDidMount() {
    this.getUserDetails();
  }

  getUserDetails = () => {
    var email = firebase.auth().currentUser.email;
    db.collection("users").where('email_ID', "==", email)
    .get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        var data = doc.data()
        this.setState({
          emailID: data.emailID,
          firstName: data.first_name,
          lastName: data.last_name,
          address: data.address,
          contact: data.contact,
          docID: doc.id
        })
      })
    })
  }

  updateUserDetails = () => {
    db.collection("users").doc(this.state.docID).update({
      "firstName": this.state.firstName,
      "lastName": this.state.lastName,
      "address": this.state.address,
      "contact": this.state.contact,
    })
    alert("Profile Updated Successfully!")
  }

  render() {
    return(
      <View>
        <MyHeader title = "Settings" 
        navigation = {this.props.navigation}/>

        <View style = {{flex: 0.66}}>
          <Text>First Name</Text>

          <TextInput style = {styles.form} 
            placeholder = {'First Name'}
            maxLength = {10}
            onChangeText = {(text) => {
              this.setState({
                firstName: text
              })
            }}
            value = {this.state.firstName}
            />

            <Text>Last Name</Text>

            <TextInput style = {styles.form} 
            placeholder = {'Last Name'}
            maxLength = {10}
            onChangeText = {(text) => {
              this.setState({
                lastName: text
              })
            }}
            value = {this.state.lastName}
            />

            <Text>Contact</Text>
            
            <TextInput style = {styles.form} 
              placeholder = {'Contact'}
              maxLength = {10}
              keyboardType = {'numeric'}
              onChangeText = {(text) => {
                this.setState({
                  contact: text
                })
              }}
              value = {this.state.contact}
              />

              <Text>Address</Text>

              <TextInput style = {styles.form} 
              placeholder = {'Address'}
              multiline = {true}
              onChangeText = {(text) => {
                this.setState({
                  address: text
                })
              }}
              value = {this.state.address}
              />

              <TouchableOpacity onPress = {() => {
                this.updateUserDetails
              }}>
                <Text>Save</Text>
              </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  /*container: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
    justifyContent: 0
  },

  title: {
    fontSize: 50,
    fontWeight: 'bold',
    color: '#0030FF'
  },
  
  textBox: {
    height: 30,
    width: 300,
    borderWidth: 2,
    margin: 10,
    padding: 5,
    borderColor: '#3030FF'
  },

  loginButton: {
    margin: 10,
    height: 50,
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F000FF',
    borderRadius: 20,
    shadowColor: 'white',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.3
  },

  signupButton: {
    margin: 10,
    height: 50,
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F000FF',
    borderRadius: 20,
    shadowColor: 'white',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.3
  },

  modal: {
    flex: 1,
    backgroundColor: 'white',
    padding: 5,
    margin: 15
  },

  registerText: {
    justifyContent: 'center',
    alignSelf: 'center',
    fontSize: 30
  },

  form: {
    height: 35,
    width: 250,
    borderWidth: 2,
    margin: 7,
    padding: 5,
    borderColor: '#FF00FF'
  }*/
})