import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Modal, ScrollView, KeyboardAvoidingView } from 'react-native';
import { Card, Icon, Header } from 'react-native-elements';
import firebase from 'firebase';
import db from '../config';

import MyHeader from '../components/myHeader';

export default class ReceiverDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user_id: firebase.auth().currentUser.email,
      username: "",
      receiver_id: this.props.navigation.getParam('details')["user_id"],
      request_id: this.props.navigation.getParam('details')["request_id"],
      book_name: this.props.navigation.getParam('details')["book_name"],
      reason_for_requesting: this.props.navigation.getParam('details')["reason_to_request"],
      reciever_name: "",
      receiver_contact: "",
      receiver_address: "",
      receiver_request: ""
    }
  }

  getUserDetails=(userId) => {
    db.collection("users").where('email_id','==', userId).get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        this.setState({
          userName: doc.data().first_name + " " + doc.data().last_name
        })
      })
    })
  }
  
  updateBookStatus = () => {
    db.collection("all_donations").add({
      "book_name": this.state.book_name,
      "request_id": this.state.request_id,
      "reqested_by": this.state.reciever_name,
      "donor_id": this.state.user_id,
      "request_status": "Donor interested"
    })
  } 

  addNotification = () => {
    var message = this.state.user_id + " has shown interest in donating!"
    db.collection("all_notifications").add({
      "targeted_user_id": this.state.receiver_id,
      "donor_id": this.state.user_id,
      "request_id": this.state.request_id,
      "book_name": this.state.book_name,
      "date": firebase.firestore.FieldValue.serverTimestamp,
      "notification_status": "unread",
      "message": message
    })
  }

  getReceiverDetails = () => {
    db.collection("users").where("email_id", "==", this.state.receiver_id)
    .get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        this.setState({
          reciever_name: doc.data().first_name,
          reciever_contact: doc.data().contact,
          reciever_address: doc.data().address,
        })
      })
    })
    
    db.collection("requested_books").where("request_id", "==", this.state.request_id)
    .get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        this.setState({
          receiver_requestDocID: doc.id
        })
      })
    })
    alert("getrecieverdetails function works")
  }

  componentDidMount() {
    this.getReceiverDetails();
    this.getUserDetails(this.state.user_id);
  }

  render() {
    return(
      <View>
        <MyHeader title = "Requested Books"/>
        
        <View style = {{flex: 0.3}}>
          <Card title = {"Book Information"}
          titleStyle = {{fontSize: 20}}>

            <Card>
              <Text>Name: {this.state.book_name}</Text>
            </Card>

            <Card>
              <Text>Reason: {this.state.reason_for_requesting}</Text>
            </Card>

          </Card>
        </View>

        <View>
          <TouchableOpacity onPress = {() => {
            this.updateBookStatus();
            this.props.navigation.navigate("myDonations");
            this.addNotification();
          }}>
            <Text>I want to donate!</Text>
          </TouchableOpacity>
        </View>

        <Text>Receiver Details</Text>
      </View>
    );
  }
}