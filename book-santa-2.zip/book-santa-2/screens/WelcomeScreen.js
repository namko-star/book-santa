import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Modal, ScrollView, KeyboardAvoidingView } from 'react-native';
import db from '../config';
import firebase from 'firebase';

export default class WelcomeScreen extends Component {
  constructor(){
    super();
    this.state = {
      emailID: "",
      password: "",
      firstName: "",
      lastName: "",
      address: "",
      contact: "",
      confirmPassword: "",
      isModalVisible: 'false'
    }
  }
  
  userSignUp = (emailID, password, confirmPassword) => {
    if(password !== confirmPassword) {
      return(alert("Password doesn't match!"))
    }

    else{
      firebase.auth().createUserWithEmailAndPassword(emailID, password)
      .then(() => {
        db.collection('users').add({
          first_name: this.state.firstName,
          last_name: this.state.lastName,
          address: this.state.address,
          contact: this.state.contact,
          email_ID: this.state.emailID,
        })
        // Signed in 
        return alert("User added successfully!", "", [{
          text: 'Ok',
          onPress: () => {this.setState({isModalVisible: 'false'})}}]);
        // ...
      })
      .catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
        return alert(errorMessage);
        // ..
        });
    }
    

  }

  userLogin = (emailID, password) => {
    firebase.auth().signInWithEmailAndPassword(emailID, password)
    .then(() => {
      // Signed in 
      this.props.navigation.navigate('DonateBooks');
      // ...
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
      return alert(errorMessage);
      // ..
  });
  }

  showModal = () => {
    return(
      <Modal animationType = "fade"
      transparent = {true}
      visible = {this.state.isModalVisible}>
        <View style = {styles.modal}>
          <ScrollView style = {{width: '100%'}}>
            <KeyboardAvoidingView style = {styles.keyboardAvoid}>
              <Text style = {styles.registerText}>Registration</Text>
              <TextInput style = {styles.form} 
              placeholder = {'First Name'}
              maxLength = {10}
              onChangeText = {(text) => {
                this.setState({
                  firstName: text
                })
              }}/>

              <TextInput style = {styles.form} 
              placeholder = {'Last Name'}
              maxLength = {10}
              onChangeText = {(text) => {
                this.setState({
                  lastName: text
                })
              }}/>

              <TextInput style = {styles.form} 
              placeholder = {'Contact'}
              maxLength = {10}
              keyboardType = {'numeric'}
              onChangeText = {(text) => {
                this.setState({
                  contact: text
                })
              }}/>

              <TextInput style = {styles.form} 
              placeholder = {'Address'}
              multiline = {true}
              onChangeText = {(text) => {
                this.setState({
                  address: text
                })
              }}/>

              <TextInput style = {styles.form} 
              placeholder = {'Email Address'}
              keyboardType = {'email-address'}
              onChangeText = {(text) => {
                this.setState({
                  emailID: text
                })
              }}/>

              <TextInput style = {styles.form} 
              placeholder = {'Password'}
              secureTextEntry = {true}
              onChangeText = {(text) => {
                this.setState({
                  password: text
                })
              }}/>

              <TextInput style = {styles.form} 
              placeholder = {'Confirm Password'}
              secureTextEntry = {true}
              onChangeText = {(text) => {
                this.setState({
                  confirmPassword: text
                })
              }}/>
              
              <View style = {{flexDirection: 'row'}}>
                <TouchableOpacity onPress = {() => {
                  this.userSignUp(this.state.emailID, this.state.password, this.state.confirmPassword)
                }}
                style = {styles.registerButtons}>
                  <Text>Register</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress = {() => {
                  this.setState({
                    isModalVisible: 'false'
                  })
                }}
                style = {styles.registerButtons}>
                  <Text>Cancel</Text>
                </TouchableOpacity>
              </View>

            </KeyboardAvoidingView>
          </ScrollView>
        </View>
      </Modal>
    );
  }

  render() {
    return(
      <View style = {styles.container}>
        <Text style = {styles.title}>Book Santa!</Text>
        
        <View>{this.showModal()}</View>

        <View>
          <TextInput style = {styles.textBox} 
          placeholder = "abc@example.com" 
          keyboardType = "email-address"
          onChangeText = {(text) => {
            this.setState({
              emailID: text
            })
          }}/>

          <TextInput style = {styles.textBox} 
          placeholder = "Password" 
          secureTextEntry = {true}
          onChangeText = {(text) => {
            this.setState({
              password: text
            })
          }}/>
        </View>
        
        <View style = {{flexDirection: 'row', padding: 10}}>
          <TouchableOpacity style = {styles.loginButton}
          onPress = {() => {
            this.userLogin(this.state.emailID, this.state.password)
          }}>
            <Text>Log In</Text>
          </TouchableOpacity>

          <TouchableOpacity style = {styles.signupButton}
          onPress = {() => {
            this.setState({
              isModalVisible: 'true'
            })
          }}>
            <Text>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
    justifyContent: 0
  },

  title: {
    fontSize: 50,
    fontWeight: 'bold',
    color: '#0030FF'
  },
  
  textBox: {
    height: 30,
    width: 300,
    borderWidth: 2,
    margin: 10,
    padding: 5,
    borderColor: '#3030FF'
  },

  loginButton: {
    margin: 10,
    height: 50,
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F000FF',
    borderRadius: 20,
    shadowColor: 'white',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.3
  },

  signupButton: {
    margin: 10,
    height: 50,
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F000FF',
    borderRadius: 20,
    shadowColor: 'white',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.3
  },

  modal: {
    flex: 1,
    backgroundColor: 'white',
    padding: 5,
    margin: 15
  },

  registerText: {
    justifyContent: 'center',
    alignSelf: 'center',
    fontSize: 30
  },

  form: {
    height: 35,
    width: 250,
    borderWidth: 2,
    margin: 7,
    padding: 5,
    borderColor: '#FF00FF'
  },

  registerButtons: {
    flex: 1,
    margin: 10,
    width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'lightblue',
    borderRadius: 20,
    shadowColor: 'white',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.3
  }
})