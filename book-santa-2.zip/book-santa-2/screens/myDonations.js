import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, KeyboardAvoidingView, FlatList } from 'react-native';
import { Icon, ListItem } from 'react-native-elements';
import MyHeader from '../components/myHeader';

import db from '../config';
import firebase from 'firebase';

export default class MyDonationsScreen extends Component {
  constructor() {
    super();
    this.state = {
      donor_id: firebase.auth().currentUser.email,
      donor_name: "",
      all_donations: []
    }
    this.requestRef = null;
  }
  
  static navigationOptions = {header: null}

  getDonorDetails = (donorID) => {
    db.collection("users").where("email_id", '==', donorID)
    .get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        this.setState({
          "donor_name": doc.data().first_name + " " + doc.data().last_name
        })
      })
    })
  }

  getAllDonations = () => {
     this.requestRef = db.collection("all_donations").where("donor_id" ,'==', this.state.donorId)
     .onSnapshot((snapshot) => {
       var allDonations = []
       snapshot.docs.map((doc) =>{
         var donation = doc.data()
         donation["doc_id"] = doc.id
         allDonations.push(donation)
       });
       this.setState({
         allDonations : allDonations
       });
     })
   }

  sendNotification = (bookDetails, requestStatus) => {
    var requestID = bookDetails.requestID;
    var donorID = bookDetails.donor_id;
    db.collection("all_notifications")
    .where("request_id", '==', requestID)
    .where("donor_id", '==', donorID)
    .get()
    .then((snapshot) => {
      snapshot.forEach((doc) => {
        var message = ""
        if(requestStatus === "book sent") {
          message = this.state.donor_name + " sent you a book!"
        }
        else {
          message = this.state.donor_name + " has shown interest in donating!"
        }

        db.collection("all_notifications").doc(doc.id).update({
          message: message, 
          notificationStatus: 'unread',
          date: firebase.firestore.FieldValue.serverTimestamp()
        })
       });
    })
  }

  sendBook = (bookDetails) => {
    if(bookDetails.request_status === "book_sent") {
      var requestStatus = "donor interested"
      db.collection("all_donations").doc(bookDetails.doc_id).update({
        requestStatus: "donor interested"
      })
      this.sendNotification(bookDetails.requestStatus)
    }
    else{
      var requestStatus = "book sent"
      db.collection("all_donations").doc(bookDetails.doc_id).update({
        requestStatus: "book sent"
      })
      this.sendNotification(bookDetails.requestStatus)
    }
  }

  renderItem = ( {item, i} ) =>(
     <ListItem
       key = {i}
       title = {item.book_name}
       subtitle = {"Requested By : " + item.requested_by +"\nStatus : " + item.request_status}
       leftElement = {<Icon name="book" type="font-awesome" color ='#696969'/>}
       titleStyle = {{ color: 'black', fontWeight: 'bold' }}
       rightElement = {
           <TouchableOpacity
            style = {[
              styles.button,
              {
                backgroundColor : item.request_status === "Book Sent" ? "green" : "#ff5722"
              }
            ]}
            onPress = {()=>{
              this.sendBook(item)
            }}
           >
             <Text style={{color:'#ffff'}}>{
               item.request_status === "Book Sent" ? "Book Sent" : "Send Book"
             }</Text>
           </TouchableOpacity>
         }
       bottomDivider
     />
   )

  render() {
    return(
      <View style = {{flex:1}}>
         <MyHeader navigation = {this.props.navigation} title = "My Donations"/>
         <View style = {{flex:1}}>
           {
             this.state.all_donations.length === 0
             ?(
               <View style = {styles.subtitle}>
                 <Text style = {{ fontSize: 20}}>List of all book Donations</Text>
               </View>
             )
             :(
               <FlatList
                 keyExtractor = {this.keyExtractor}
                 data = {this.state.allDonations}
                 renderItem = {this.renderItem}
               />
             )
           }
         </View>
       </View>
    );
  }
}

const styles = StyleSheet.create({
  
})