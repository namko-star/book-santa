import firebase from 'firebase';

require ("@firebase/firestore");
var firebaseConfig = {
    apiKey: "AIzaSyB_UGgneXKKXEkkJcvV9o7e_5f6ZoHDlKw",
    authDomain: "book-santa-876b7.firebaseapp.com",
    projectId: "book-santa-876b7",
    databaseURL: "https://book-santa-876b7.firebaseio.com",
    storageBucket: "book-santa-876b7.appspot.com",
    messagingSenderId: "135554436853",
    appId: "1:135554436853:web:31f767e2b01c53b2a43fbc"
};

firebase.initializeApp(firebaseConfig);
export default firebase.firestore();